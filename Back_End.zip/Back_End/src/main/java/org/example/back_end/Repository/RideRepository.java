package org.example.back_end.Repository;

import org.example.back_end.Entity.Ride;
import org.example.back_end.Entity.User;
import org.example.back_end.Entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RideRepository extends JpaRepository<Ride, Long> {
    // Find all rides by a user
    List<Ride> findByUser(User user);

    // Find all rides by vehicle
    List<Ride> findByVehicle(Vehicle vehicle);

    // Find rides by status (REQUESTED, ACCEPTED, COMPLETED)
    List<Ride> findByStatus(String status);

    // Combined example: rides by user and status
    List<Ride> findByUserAndStatus(User user, String status);
}
