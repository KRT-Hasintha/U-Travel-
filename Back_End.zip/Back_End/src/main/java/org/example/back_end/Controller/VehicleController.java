package org.example.back_end.Controller;

import lombok.RequiredArgsConstructor;
import org.example.back_end.Entity.Vehicle;
import org.example.back_end.Service.VehicleService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/vehicles")
@RequiredArgsConstructor
@CrossOrigin
public class VehicleController {
    private final VehicleService vehicleService;

    // PROVIDER → add vehicle
    @PostMapping
    @PreAuthorize("hasAnyRole('PROVIDER','ADMIN')")
    public Vehicle addVehicle(@RequestBody Vehicle vehicle){
        return vehicleService.save(vehicle);
    }

    // PROVIDER → update vehicle live location
    @PutMapping("/location")
    @PreAuthorize("hasAnyRole('PROVIDER','ADMIN')")
    public Vehicle updateLocation(
            @RequestParam Long vehicleId,
            @RequestParam Double lat,
            @RequestParam Double lng
    ){
        return vehicleService.updateLocation(vehicleId, lat, lng);
    }

    // USER → get nearby vehicles
    @GetMapping("/nearby")
    @PreAuthorize("hasRole('USER')")
    public List<Vehicle> getNearby(@RequestParam Double lat,
                                   @RequestParam Double lng){
        return vehicleService.getAll(); // later filter by distance
    }
}
