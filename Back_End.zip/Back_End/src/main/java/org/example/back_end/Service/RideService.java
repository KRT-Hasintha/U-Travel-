package org.example.back_end.Service;

import lombok.RequiredArgsConstructor;
import org.example.back_end.Entity.Ride;
import org.example.back_end.Entity.User;
import org.example.back_end.Entity.Vehicle;
import org.example.back_end.Repository.RideRepository;
import org.example.back_end.Repository.UserRepository;
import org.example.back_end.Repository.VehicleRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RideService {
    private final RideRepository rideRepository;
    private final VehicleRepository vehicleRepository;
    private final UserRepository userRepository;

    // USER → request ride
    public Ride save(Ride ride){
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        ride.setUser(user);
        ride.setStatus("REQUESTED");
        return rideRepository.save(ride);
    }

    // PROVIDER → accept ride
    public Ride acceptRide(Long rideId, Long vehicleId){
        Ride ride = rideRepository.findById(rideId)
                .orElseThrow(() -> new RuntimeException("Ride not found"));

        Vehicle vehicle = vehicleRepository.findById(vehicleId)
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));

        ride.setVehicle(vehicle);
        ride.setStatus("ACCEPTED");

        return rideRepository.save(ride);
    }

}
