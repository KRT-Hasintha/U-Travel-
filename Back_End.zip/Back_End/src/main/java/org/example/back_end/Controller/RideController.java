package org.example.back_end.Controller;


import lombok.RequiredArgsConstructor;
import org.example.back_end.Entity.Ride;
import org.example.back_end.Service.RideService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/rides")
@RequiredArgsConstructor
@CrossOrigin
public class RideController {

    private final RideService rideService;

    // USER → request a ride
    @PostMapping("/request")
    @PreAuthorize("hasRole('USER')")
    public Ride requestRide(@RequestBody Ride ride){
        ride.setStatus("REQUESTED");
        return rideService.save(ride);
    }

    // PROVIDER → accept a ride
    @PutMapping("/accept")
    @PreAuthorize("hasAnyRole('PROVIDER','ADMIN')")
    public Ride acceptRide(@RequestParam Long rideId,
                           @RequestParam Long vehicleId){
        return rideService.acceptRide(rideId, vehicleId);
    }
}
