package org.example.back_end.Controller;

import lombok.RequiredArgsConstructor;
import org.example.back_end.Entity.Villa;
import org.example.back_end.Repository.VillaRepository;
import org.example.back_end.Service.VillaService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/v1/villas")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class villaController {


    private final VillaService villaService;


    @PostMapping
    @PreAuthorize("hasAnyRole('PROVIDER','ADMIN')")
    public Villa addVilla(@RequestBody Villa villa){
        return villaService.addVilla(villa);
    }

    // ✅ USER kenekta district ekata anuwa villas ganna
    @GetMapping("/by-district")
    @PreAuthorize("hasRole('USER')")
    public List<Villa> getByDistrict(@RequestParam String district){
        return villaService.getVillasByDistrict(district);

//        http://localhost:8080/api/v1/villas/by-district?district=Galle
    }
}
